package exa;

public class SQLTerm {
}
