package exa;

public class DBAppException extends Exception {
	
}
